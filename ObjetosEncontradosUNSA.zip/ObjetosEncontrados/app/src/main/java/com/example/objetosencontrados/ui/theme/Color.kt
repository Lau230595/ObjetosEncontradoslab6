package com.example.objetosencontrados.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
val Granate = Color(0xFF8B1A2A)
val GranateClaro = Color(0xFFF5E8EA)
val FondoApp = Color(0xFFF1F2F6)
val Exito = Color(0xFF2E8A50)
val Error = Color(0xFFC0392B)
val Advertencia = Color(0xFFD99A00)